import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import productRoutes from "./routes/productRoutes.js";
import paymentRoutes from "./routes/paymentRoutes.js";

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/ecommerce");

app.use("/api/products", productRoutes);
app.use("/api/payment", paymentRoutes);

app.listen(5000, () => {
  console.log("Servidor rodando na porta 5000");
});