import express from "express";
const router = express.Router();

const products = [
  { id: 1, name: "Notebook Gamer", price: 4500, image: "https://via.placeholder.com/150" },
  { id: 2, name: "Smartphone", price: 2500, image: "https://via.placeholder.com/150" }
];

router.get("/", (req, res) => {
  res.json(products);
});

export default router;