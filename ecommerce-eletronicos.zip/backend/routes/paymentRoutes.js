import express from "express";
import Stripe from "stripe";

const router = express.Router();
const stripe = new Stripe("SUA_CHAVE_SECRETA_STRIPE");

router.post("/checkout", async (req, res) => {
  const { items } = req.body;

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: items.map(item => ({
      price_data: {
        currency: "brl",
        product_data: { name: item.name },
        unit_amount: item.price * 100
      },
      quantity: 1
    })),
    mode: "payment",
    success_url: "http://localhost:5500/frontend/success.html",
    cancel_url: "http://localhost:5500/frontend/cancel.html"
  });

  res.json({ id: session.id });
});

export default router;