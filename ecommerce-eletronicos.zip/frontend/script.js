let cart = JSON.parse(localStorage.getItem("cart")) || [];

fetch("http://localhost:5000/api/products")
  .then(res => res.json())
  .then(products => {
    const div = document.getElementById("products");
    products.forEach(p => {
      div.innerHTML += `
        <div>
          <h3>${p.name}</h3>
          <p>R$ ${p.price}</p>
          <button onclick='addToCart(${JSON.stringify(p)})'>Comprar</button>
        </div>
      `;
    });
  });

function addToCart(product) {
  cart.push(product);
  localStorage.setItem("cart", JSON.stringify(cart));
}